﻿using Microsoft.AspNetCore.Mvc;

namespace Hotel.Controllers
{
    public class RegisterController : Controller
    {
        public IActionResult index()
        {
            return View();
        }
    }
}
